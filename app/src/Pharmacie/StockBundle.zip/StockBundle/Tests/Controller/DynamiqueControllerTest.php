<?php

namespace Gestion\StockBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DynamiqueControllerTest extends WebTestCase
{
}
