<?php

namespace Pharmacie\StockBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PharmacieStockBundle extends Bundle
{
}
